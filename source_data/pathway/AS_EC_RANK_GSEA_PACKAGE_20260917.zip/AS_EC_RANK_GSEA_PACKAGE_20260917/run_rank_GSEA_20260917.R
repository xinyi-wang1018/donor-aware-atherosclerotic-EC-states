#!/usr/bin/env Rscript
options(stringsAsFactors = FALSE)
set.seed(20260917)

args_all <- commandArgs(trailingOnly = FALSE)
file_arg <- sub("^--file=", "", grep("^--file=", args_all, value = TRUE))
SCRIPT_DIR <- if (length(file_arg)) dirname(normalizePath(file_arg[1])) else getwd()
REF_DIR <- file.path(SCRIPT_DIR, "reference_sets")
OUT <- "/root/AS_EC_RANK_GSEA_20260917"
dir.create(OUT, recursive=TRUE, showWarnings=FALSE)

logf <- file.path(OUT, "RUN_LOG.txt")
zz <- file(logf, open="wt")
sink(zz, type="output")
sink(zz, type="message")
on.exit({
  sink(type="message"); sink(type="output"); close(zz)
}, add=TRUE)

cat("AS EC rank-based GSEA\n")
cat("Date:", as.character(Sys.time()), "\n")
cat("Script:", normalizePath(file_arg[1]), "\n\n")

# ---------- Find final frozen 3375-gene source data ----------
candidates <- c(
  "/root/AS_EC_C3C7_FINAL_FREEZE_20260904/05_final_freeze/FINAL_FROZEN_C3_vs_C7_full_source_data.csv",
  "/root/AS_EC_C3C7_FINAL_FREEZE_20260904/AS_EC_C3C7_FINAL_FREEZE_20260904/05_final_freeze/FINAL_FROZEN_C3_vs_C7_full_source_data.csv"
)
found <- candidates[file.exists(candidates)]
if (!length(found)) {
  found <- system("find /root -type f -name 'FINAL_FROZEN_C3_vs_C7_full_source_data.csv' 2>/dev/null | head -n 1", intern=TRUE)
}
if (!length(found) || !file.exists(found[1])) stop("Final frozen C3-vs-C7 source-data CSV not found.")
INFILE <- found[1]
cat("Input:", INFILE, "\n")

de <- read.csv(INFILE, check.names=FALSE)
need <- c("gene","logFC","F","PValue","FDR")
if (!all(need %in% names(de))) stop("Input missing required columns: ", paste(setdiff(need,names(de)),collapse=", "))
de <- de[is.finite(de$logFC) & is.finite(de$F) & !is.na(de$gene) & de$gene!="", ]
if (nrow(de) != 3375) warning("Expected 3375 tested genes; found ", nrow(de))

de$rank_signed_sqrtF <- sign(de$logFC) * sqrt(pmax(de$F,0))
# Resolve any duplicate gene names by retaining largest absolute statistic.
ord <- order(abs(de$rank_signed_sqrtF), decreasing=TRUE)
de <- de[ord,]
de <- de[!duplicated(de$gene),]
ranks <- de$rank_signed_sqrtF
names(ranks) <- de$gene
ranks <- sort(ranks, decreasing=TRUE)
write.csv(data.frame(gene=names(ranks), rank_signed_sqrtF=unname(ranks)),
          file.path(OUT,"01_ranked_3375_genes.csv"), row.names=FALSE)

# ---------- Load bundled gene sets ----------
read_set <- function(f) {
  x <- trimws(readLines(f, warn=FALSE))
  unique(x[nzchar(x) & !grepl("^#",x)])
}
txts <- list.files(REF_DIR, pattern="\\.txt$", full.names=TRUE)
txts <- txts[basename(txts)!="REFERENCE_SET_NOTES.txt"]
pathways <- setNames(lapply(txts, read_set), sub("\\.txt$","",basename(txts)))

# ---------- Add standardized Hallmark sets if msigdbr exists ----------
hallmark_status <- "msigdbr not installed; standardized Hallmark panel skipped"
if (requireNamespace("msigdbr", quietly=TRUE)) {
  ms <- tryCatch(msigdbr::msigdbr(species="Homo sapiens", collection="H"),
                 error=function(e) tryCatch(msigdbr::msigdbr(species="Homo sapiens", category="H"),
                                            error=function(e2) NULL))
  if (!is.null(ms)) {
    nmcol <- if ("gs_name" %in% names(ms)) "gs_name" else NULL
    gcol <- if ("gene_symbol" %in% names(ms)) "gene_symbol" else NULL
    wanted <- c(
      "HALLMARK_EPITHELIAL_MESENCHYMAL_TRANSITION",
      "HALLMARK_ANGIOGENESIS",
      "HALLMARK_INFLAMMATORY_RESPONSE",
      "HALLMARK_HYPOXIA",
      "HALLMARK_TNFA_SIGNALING_VIA_NFKB",
      "HALLMARK_TGF_BETA_SIGNALING",
      "HALLMARK_IL6_JAK_STAT3_SIGNALING",
      "HALLMARK_INTERFERON_GAMMA_RESPONSE",
      "HALLMARK_COAGULATION",
      "HALLMARK_APOPTOSIS"
    )
    if (!is.null(nmcol) && !is.null(gcol)) {
      ms <- ms[ms[[nmcol]] %in% wanted, c(nmcol,gcol)]
      for (nm in unique(ms[[nmcol]])) pathways[[nm]] <- unique(ms[ms[[nmcol]]==nm,gcol])
      hallmark_status <- paste0("msigdbr Hallmark panel added: ", length(unique(ms[[nmcol]])), " sets")
    }
  }
}
cat(hallmark_status,"\n")

# Filter by actual tested-gene overlap.
tested <- names(ranks)
manifest <- do.call(rbind, lapply(names(pathways), function(nm) {
  g <- unique(pathways[[nm]])
  ov <- intersect(g, tested)
  data.frame(pathway=nm, source_size=length(g), tested_overlap_n=length(ov),
             tested_overlap_genes=paste(ov,collapse=";"), stringsAsFactors=FALSE)
}))
write.csv(manifest, file.path(OUT,"02_gene_set_manifest.csv"), row.names=FALSE)

valid_names <- manifest$pathway[manifest$tested_overlap_n >= 5 & manifest$tested_overlap_n <= 500]
pathways2 <- pathways[valid_names]
pathways2 <- lapply(pathways2, intersect, y=tested)
cat("Gene sets retained with 5-500 tested genes:", length(pathways2), "\n")

# ---------- Standard fgsea if available; pure-R fallback otherwise ----------
use_fgsea <- requireNamespace("fgsea", quietly=TRUE)
method <- if (use_fgsea) "fgseaMultilevel" else "pure-R weighted GSEA with 2000 random gene-set permutations"
cat("Method:",method,"\n")

if (use_fgsea) {
  fg <- fgsea::fgseaMultilevel(pathways=pathways2, stats=ranks, minSize=5, maxSize=500, eps=0)
  fg <- as.data.frame(fg)
  if ("leadingEdge" %in% names(fg)) fg$leadingEdge <- vapply(fg$leadingEdge, paste, collapse=";", FUN.VALUE=character(1))
  names(fg)[names(fg)=="pathway"] <- "pathway"
  res <- fg
} else {
  calc_es <- function(stats, genes) {
    hit <- names(stats) %in% genes
    Nh <- sum(hit); N <- length(stats)
    if (Nh < 1 || Nh >= N) return(list(ES=NA_real_, leading=character()))
    wh <- abs(stats)
    denom <- sum(wh[hit])
    if (!is.finite(denom) || denom<=0) return(list(ES=NA_real_, leading=character()))
    phit <- cumsum(ifelse(hit, wh/denom, 0))
    pmiss <- cumsum(ifelse(!hit, 1/(N-Nh), 0))
    rs <- phit-pmiss
    imax <- which.max(rs); imin <- which.min(rs)
    if (abs(rs[imax]) >= abs(rs[imin])) {
      es <- rs[imax]
      lead <- names(stats)[seq_len(imax)]
      lead <- lead[lead %in% genes]
    } else {
      es <- rs[imin]
      lead <- names(stats)[imin:N]
      lead <- lead[lead %in% genes]
    }
    list(ES=es, leading=lead)
  }

  B <- 2000L
  universe <- names(ranks)
  out <- vector("list", length(pathways2))
  for (i in seq_along(pathways2)) {
    nm <- names(pathways2)[i]
    gs <- pathways2[[i]]
    obs <- calc_es(ranks, gs)
    k <- length(gs)
    null <- numeric(B)
    for (b in seq_len(B)) {
      rnd <- sample(universe, k, replace=FALSE)
      null[b] <- calc_es(ranks, rnd)$ES
    }
    if (is.na(obs$ES)) {
      nes <- p <- NA_real_
    } else if (obs$ES >= 0) {
      denom <- mean(null[null>=0], na.rm=TRUE)
      nes <- obs$ES/denom
      p <- (1 + sum(null >= obs$ES, na.rm=TRUE))/(B+1)
    } else {
      denom <- abs(mean(null[null<0], na.rm=TRUE))
      nes <- obs$ES/denom
      p <- (1 + sum(null <= obs$ES, na.rm=TRUE))/(B+1)
    }
    out[[i]] <- data.frame(pathway=nm, pval=p, padj=NA_real_, ES=obs$ES, NES=nes,
                           size=k, leadingEdge=paste(obs$leading,collapse=";"),
                           stringsAsFactors=FALSE)
  }
  res <- do.call(rbind,out)
  res$padj <- p.adjust(res$pval, method="BH")
}

# Standardize field names for downstream manuscript/source data.
if ("pval" %in% names(res)) names(res)[names(res)=="pval"] <- "PValue"
if ("padj" %in% names(res)) names(res)[names(res)=="padj"] <- "FDR"
if ("size" %in% names(res)) names(res)[names(res)=="size"] <- "tested_set_size"
if (!"NES" %in% names(res) && "nes" %in% names(res)) names(res)[names(res)=="nes"] <- "NES"

res <- res[order(res$FDR, -abs(res$NES), na.last=TRUE),]
write.csv(res, file.path(OUT,"03_rank_GSEA_all_sets.csv"), row.names=FALSE)

core <- res[grepl("Slenders|Wu2026|Botts|Yao2026|CURATED|HALLMARK", res$pathway),]
write.csv(core, file.path(OUT,"04_rank_GSEA_prespecified_panel.csv"), row.names=FALSE)

# ---------- Simple base-R dot plot ----------
png(file.path(OUT,"05_rank_GSEA_prespecified_panel.png"), width=1800, height=1400, res=180)
par(mar=c(5,15,3,2))
plotdf <- core[is.finite(core$NES),]
if (nrow(plotdf)) {
  plotdf <- plotdf[order(plotdf$NES),]
  y <- seq_len(nrow(plotdf))
  fdr_safe <- pmax(plotdf$FDR, 1e-12)
  cex <- pmin(2.4, 0.7 + (-log10(fdr_safe))/4)
  pch <- ifelse(plotdf$NES>=0, 16, 1)
  plot(plotdf$NES, y, yaxt="n", ylab="", xlab="Normalized enrichment score (NES)",
       pch=pch, cex=cex, main="Rank-based enrichment of frozen C3 vs C7 statistics")
  axis(2, at=y, labels=plotdf$pathway, las=2, cex.axis=0.72)
  abline(v=0,lty=2)
  legend("bottomright", legend=c("C3-enriched NES > 0","C7-enriched NES < 0"),
         pch=c(16,1), bty="n")
} else {
  plot.new(); text(.5,.5,"No valid pathway results")
}
dev.off()

# ---------- Report ----------
sig <- res[is.finite(res$FDR) & res$FDR < 0.05,]
cat("\nSignificant sets FDR<0.05:",nrow(sig),"\n")
if (nrow(sig)) print(sig[,intersect(c("pathway","NES","PValue","FDR","tested_set_size","leadingEdge"),names(sig))])

writeLines(c(
  "RANK-BASED GSEA METHODS",
  paste0("Input: ",INFILE),
  "Ranking statistic: sign(logFC) * sqrt(edgeR quasi-likelihood F).",
  paste0("Enrichment engine: ",method),
  hallmark_status,
  "Gene-set inclusion for testing: 5-500 genes overlapping the frozen 3,375-gene tested universe.",
  "Positive NES indicates enrichment toward C3-up end of the ranked list; negative NES indicates enrichment toward C7-up end.",
  "Literature reference sets and CURATED panels are documented in reference_sets/REFERENCE_SET_NOTES.txt.",
  "This analysis uses the complete ranked tested-gene universe and is independent of the logFC > 0.5 C3-up cutoff."
), file.path(OUT,"METHODS_AND_INTERPRETATION.txt"))

# Copy reference notes for provenance.
file.copy(file.path(REF_DIR,"REFERENCE_SET_NOTES.txt"), file.path(OUT,"REFERENCE_SET_NOTES.txt"), overwrite=TRUE)

# Bundle.
system(sprintf("tar -czf /root/AS_EC_RANK_GSEA_20260917.tar.gz -C /root %s", basename(OUT)))
cat("\nDONE\nUpload: /root/AS_EC_RANK_GSEA_20260917.tar.gz\n")
