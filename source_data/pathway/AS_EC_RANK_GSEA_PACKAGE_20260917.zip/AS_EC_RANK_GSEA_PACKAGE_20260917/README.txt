AS EC rank-based GSEA package

Purpose
-------
Address reviewer comments that the literature/program comparison should not depend only on the thresholded C3-up gene list.

Run
---
Upload this whole folder/zip to the server, unzip under /root, then:

Rscript /root/AS_EC_RANK_GSEA_PACKAGE_20260917/run_rank_GSEA_20260917.R

Output
------
/root/AS_EC_RANK_GSEA_20260917.tar.gz

The script:
1. finds the frozen 3,375-gene C3-vs-C7 edgeR table;
2. ranks all tested genes by sign(logFC)*sqrt(F);
3. tests Slenders/Wu/Botts/Yao reference programs plus transparent curated EC functional panels;
4. also adds selected MSigDB Hallmark sets if msigdbr is already installed;
5. uses fgseaMultilevel when fgsea is installed, otherwise a package-free weighted GSEA permutation fallback;
6. creates source tables, a simple dot plot, and a methods note.
